# mii-exa-studie-consent - MII Implementation Guide Medizinisches Forschungsvorhaben v2026.0.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-studie-consent**

## Beispiel Consent: mii-exa-studie-consent

-------

**German**

-------

## Participants

* **Role**: Patient
  * **Details**: [Jane Doe Female, DoB: 1980-11-12 ( KVZ10 (use: official, ))](Patient-mii-exa-studie-patient.md)

This consent is made under the policy `urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791` .

The subject has given their consent.



## Resource Content

```json
{
  "resourceType" : "Consent",
  "id" : "mii-exa-studie-consent",
  "status" : "active",
  "scope" : {
    "coding" : [{
      "code" : "research"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "59284-0"
    }]
  }],
  "patient" : {
    "reference" : "Patient/mii-exa-studie-patient"
  },
  "policy" : [{
    "uri" : "urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791"
  }]
}

```
